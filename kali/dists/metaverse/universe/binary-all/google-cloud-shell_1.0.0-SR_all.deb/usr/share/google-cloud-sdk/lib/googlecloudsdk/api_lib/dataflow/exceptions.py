# -*- coding: utf-8 -*- #
# Copyright 2018 Google LLC. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Exceptions for interacting with the Cloud Dataflow API.
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from googlecloudsdk.core import exceptions


class Error(exceptions.Error):
  """Base class for dataflow exceptions."""


class ServiceException(Error):
  """Generic exception related to calling the Dataflow service APIs."""


class UnsupportedNameException(Error):
  """Exception raised if a name is incompatible with Graphviz ID escaping."""


class InvalidExclusionException(Error):
  """Raised if a user tries to exclude incompatible metrics."""
